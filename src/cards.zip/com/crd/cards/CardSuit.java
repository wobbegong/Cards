package com.crd.cards;
/**
 * Enumeration of the possible suits of a card
 */
 public enum CardSuit {
	 HEART,
	 DIAMOND,
	 SPADE,
	 CLOVER;
 }
